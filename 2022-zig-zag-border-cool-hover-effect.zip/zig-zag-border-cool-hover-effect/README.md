# Zig-zag border & cool hover effect

A Pen created on CodePen.io. Original URL: [https://codepen.io/t_afif/pen/BarmdPB](https://codepen.io/t_afif/pen/BarmdPB).

CSS Tip!
https://twitter.com/ChallengesCss/status/1552973452402884609