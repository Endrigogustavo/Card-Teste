# input with gradient-border - dark

A Pen created on CodePen.io. Original URL: [https://codepen.io/enbee81/pen/GRJVgXj](https://codepen.io/enbee81/pen/GRJVgXj).

