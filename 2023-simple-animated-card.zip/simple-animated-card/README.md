# Simple Animated Card

A Pen created on CodePen.io. Original URL: [https://codepen.io/jepooley/pen/NWYryap](https://codepen.io/jepooley/pen/NWYryap).

Super simple card, which reveals extra text and hyperlink on hover